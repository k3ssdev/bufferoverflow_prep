# Tryhackme-BufferOverflow-prep
    The SLMail installer.
    The brainpan binary.
    The dostackbufferoverflowgood binary.
    The vulnserver binary.
    A custom written "oscp" binary which contains 10 buffer overflows, each with a different EIP offset and set of badchars.
